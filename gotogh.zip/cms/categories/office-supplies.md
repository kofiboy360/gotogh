---
f_short-description: >-
  GSM wireless telephone, files and book shelves , swivel chair, visitor chair,
  computer desk. 
title: Office Supplies
slug: office-supplies
updated-on: '2023-12-18T15:17:02.866Z'
created-on: '2023-12-18T15:03:00.232Z'
published-on: '2023-12-18T17:41:20.787Z'
f_category-image:
  url: >-
    /assets/external/6580626acca6377dd4d65bd1_photo-1456735190827-d1262f71b8a3.png
  alt: null
layout: '[categories].html'
tags: categories
---


