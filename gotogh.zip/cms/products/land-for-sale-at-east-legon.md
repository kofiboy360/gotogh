---
f_price: 84961.96
title: Land for sale at East Legon
f_description: |-
  Iusto distinctio corrupti omnis ducimus non quia illum at.
  Laboriosam est fugit doloremque hic pariatur eos.
  Minus quis quia et doloremque repellendus adipisci.
  Facilis eum dolorem nemo qui ut officiis.
  Nobis vel consequuntur impedit hic.
  Soluta nesciunt eaque.
  Sint et delectus occaecati officiis v
f_product-images:
  - url: /assets/external/6582286d07007738c195b8fb_image12.jpeg
    alt: null
f_main-product-image:
  url: /assets/external/658d97a67b58e8edf2c22e1c_land-for-sale-in-accra3.jpg
  alt: null
slug: land-for-sale-at-east-legon
f_category-2: cms/categories/real-estate.md
updated-on: '2023-12-28T15:44:34.348Z'
created-on: '2023-12-19T23:34:07.440Z'
published-on: '2023-12-28T15:52:47.345Z'
layout: '[products].html'
tags: products
---


